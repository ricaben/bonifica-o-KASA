BÔNUS KASA ESFIHAS — PROJETO ANDROID

Nome do aplicativo: Bônus Kasa Esfihas
Pacote: com.kasaesfihas.bonus
Versão: 1.0

O aplicativo funciona sem internet. Os dados ficam salvos no aparelho.

COMO GERAR O APK NO ANDROID STUDIO
1. Instale o Android Studio.
2. Abra esta pasta como projeto.
3. Aguarde a sincronização do Gradle.
4. No menu, selecione Build > Build APK(s).
5. O APK será criado em app/build/outputs/apk/debug/app-debug.apk.

Para distribuição interna, o APK debug pode ser instalado diretamente.
Para publicação ou distribuição definitiva, gere uma versão assinada em:
Build > Generate Signed Bundle / APK > APK.
